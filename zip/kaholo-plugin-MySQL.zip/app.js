var mysql = require("mysql");
var fs = require("fs");

function executeQuery(action) {
  return new Promise(function(resolve, reject) {
    var connection = mysql.createConnection({
      host: action.params.HOST,
      port: action.params.PORT,
      user: action.params.USER,
      password: action.params.PASSWORD,
      database: action.params.DB
    });
    connection.connect(function(err) {
      if (err) return reject(new Error("Can't authenticate"));

      connection.query(action.params.QUERY, function(err, rows, fields) {
        connection.end();
        if (err) return reject(err);
        return resolve(rows);
      });
    });
  });
}

function executeSQLFile(action) {
  return new Promise(function(resolve, reject) {
    var connection = mysql.createConnection({
      host: action.params.HOST,
      port: action.params.PORT,
      user: action.params.USER,
      password: action.params.PASSWORD,
      database: action.params.DB,
      multipleStatements: true
    });

    connection.connect(function(err) {
      if (err) return reject(new Error("Can't authenticate"));

      fs.readFile(action.params.PATH, "utf8", function(err, queries) {
        if (err) return reject(err);

        connection.query(queries, function(err, results) {
          connection.end();
          if (err) return reject(err);
          return resolve(results);
        });
      });
    });
  });
}

module.exports = {
  executeQuery: executeQuery,
  executeSQLFile: executeSQLFile
};
